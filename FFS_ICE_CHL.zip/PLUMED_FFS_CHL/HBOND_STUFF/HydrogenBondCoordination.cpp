/* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
   Copyright (c) 2012-2015 The plumed team
   (see the PEOPLE file at the root of the distribution for a list of names)

   See http://www.plumed-code.org for more information.

   This file is part of plumed, version 2.

   plumed is free software: you can redistribute it and/or modify
   it under the terms of the GNU Lesser General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   plumed is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public License
   along with plumed.  If not, see <http://www.gnu.org/licenses/>.
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
#include "MultiColvar.h"
#include "tools/NeighborList.h"
#include "core/ActionRegister.h"
#include "tools/SwitchingFunction.h"
#include "tools/Angle.h"

#include <string>
#include <cmath>

using namespace std;

namespace PLMD{
namespace multicolvar{

//+PLUMEDOC MCOLVAR HBOND_COORD
/*

\par Example

*/
//+ENDPLUMEDOC


class HydrogenBondCoordination : public MultiColvar {
private:
  unsigned noxygens;
  double rcut2, rcuth2, acut;
public:
  static void registerKeywords( Keywords& keys );
  explicit HydrogenBondCoordination(const ActionOptions&);
/// This has no derivatives
  void turnOnDerivatives();
// active methods:
  virtual double compute( const unsigned& tindex, AtomValuePack& myatoms ) const ; 
/// Returns the number of coordinates of the field
  bool isPeriodic(){ return false; }
};

PLUMED_REGISTER_ACTION(HydrogenBondCoordination,"HBOND_COORD")

void HydrogenBondCoordination::registerKeywords( Keywords& keys ){
  MultiColvar::registerKeywords( keys );
  keys.use("SPECIES"); keys.use("SPECIESA"); keys.use("SPECIESB");
  keys.add("atoms","HYDROGENS","the hydrogen atoms");
  keys.add("compulsory","RCUTOO","the distance cutoff");
  keys.add("compulsory","RCUTOH","another distance cutoff");
  keys.add("compulsory","ACUT","the angular cutoff");
}

HydrogenBondCoordination::HydrogenBondCoordination(const ActionOptions&ao):
PLUMED_MULTICOLVAR_INIT(ao)
{
  // Read in the switching function
  double rcut; parse("RCUTOO",rcut); rcut2=rcut*rcut; 
  double rcuth; parse("RCUTOH",rcuth); rcuth2=rcuth*rcuth; parse("ACUT",acut);
  log.printf("  hydrogen bond exists if atoms are within %f and angle is less than %f \n",rcut,acut );
  // Set the link cell cutoff
  setLinkCellCutoff( rcut );
  
  // Read in the atoms
  int natoms=2; readAtoms( natoms );
  // Now we have to read the hydrogens
  std::vector<AtomNumber> atoms; parseAtomList("HYDROGENS",atoms);
  std::vector<AtomNumber> all_atoms( getAbsoluteIndexes() ); noxygens=all_atoms.size();
  for(unsigned i=0;i<atoms.size();++i) all_atoms.push_back( atoms[i] );
  setupMultiColvarBase( all_atoms );

  // And setup the ActionWithVessel
  checkRead();
}

void HydrogenBondCoordination::turnOnDerivatives(){
   error("cannot calculate derivatives of hydrogen bond coordination.  This quantity is not differentiable for now");
} 

double HydrogenBondCoordination::compute( const unsigned& tindex, AtomValuePack& myatoms ) const {
   double d2, value=0; 

   unsigned jatom=myatoms.getIndex(0), jh1=noxygens + jatom, jh2=2*noxygens + jatom;
   Vector hvec1 = getSeparation( getPositionOfAtomForLinkCells( jatom ), getPositionOfAtomForLinkCells( jh1 ) ); 
   Vector hvec2 = getSeparation( getPositionOfAtomForLinkCells( jatom ), getPositionOfAtomForLinkCells( jh2 ) ); 

   // Calculate the coordination number
   for(unsigned i=1;i<myatoms.getNumberOfAtoms();++i){
      Vector& distance=myatoms.getPosition(i);  
      if ( (d2=distance[0]*distance[0])<rcut2 && 
           (d2+=distance[1]*distance[1])<rcut2 &&
           (d2+=distance[2]*distance[2])<rcut2) {
  
         unsigned iatom=myatoms.getIndex(i), ih1=noxygens + iatom, ih2=2*noxygens + iatom;

         Vector hvec3 = getSeparation( getPositionOfAtomForLinkCells(jatom), getPositionOfAtomForLinkCells(ih1) );
         Vector hvec4 = getSeparation( getPositionOfAtomForLinkCells(jatom), getPositionOfAtomForLinkCells(ih2) );

         double hvec1_l2=getSeparation( getPositionOfAtomForLinkCells(iatom), getPositionOfAtomForLinkCells(jh1) ).modulo2();
         double hvec2_l2=getSeparation( getPositionOfAtomForLinkCells(iatom), getPositionOfAtomForLinkCells(jh2) ).modulo2();
         double hvec3_l2=getSeparation( getPositionOfAtomForLinkCells(jatom), getPositionOfAtomForLinkCells(ih1) ).modulo2();
         double hvec4_l2=getSeparation( getPositionOfAtomForLinkCells(jatom), getPositionOfAtomForLinkCells(ih2) ).modulo2();

         Angle a;
         if( hvec1_l2<rcuth2 && a.compute( distance, hvec1 )<acut ) value+=1;
         if( hvec2_l2<rcuth2 && a.compute( distance, hvec2 )<acut ) value+=1; 
         if( hvec3_l2<rcuth2 && a.compute( distance, hvec3 )<acut ) value+=1;
         if( hvec4_l2<rcuth2 && a.compute( distance, hvec4 )<acut ) value+=1;
      }
   }

   return value;
}

}
}

