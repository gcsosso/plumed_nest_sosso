#include "../../multicolvar/VolumeGradientBase.h"
