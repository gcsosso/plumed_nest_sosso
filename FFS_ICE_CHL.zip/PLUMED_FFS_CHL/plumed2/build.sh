
where=`pwd`
cd $where
rm -r -f BIN Makefile.conf
mkdir BIN
cd BIN
pref=`pwd`
cd $where
cd src
rm -r -f crystallization.on adjmat.on
touch crystallization.on ; touch adjmat.on
cd $where
cp ../HBOND_STUFF/* src/multicolvar
cp ../SPHERE_STUFF/* src/multicolvar
./configure --prefix=$pref CXX=mpic++ CC=mpicc LDFLAGS="-lmpi_cxx -lstdc++"
make clean
make -j 16
make -j 16 install
