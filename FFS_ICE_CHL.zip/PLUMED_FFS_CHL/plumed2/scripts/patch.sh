#! /bin/bash

"${PLUMED_ROOT}"/patches/patch.sh "$@"

