/* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
   Copyright (c) 2012-2014 The plumed team
   (see the PEOPLE file at the root of the distribution for a list of names)

   See http://www.plumed-code.org for more information.

   This file is part of plumed, version 2.

   plumed is free software: you can redistribute it and/or modify
   it under the terms of the GNU Lesser General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   plumed is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public License
   along with plumed.  If not, see <http://www.gnu.org/licenses/>.
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

#include "core/ActionRegister.h"
#include "tools/Pbc.h"
#include "tools/SwitchingFunction.h"
#include "ActionVolume.h"

namespace PLMD {
namespace multicolvar {

class VolumeAround_SPH : public ActionVolume {
private:
  Vector origin;
  SwitchingFunction switchingFunction;
public:
  static void registerKeywords( Keywords& keys );
  VolumeAround_SPH(const ActionOptions& ao);
  void setupRegions();
  double calculateNumberInside( const Vector& cpos, Vector& derivatives, Tensor& vir, std::vector<Vector>& refders ) const ;
}; 

PLUMED_REGISTER_ACTION(VolumeAround_SPH,"AROUND_SPH")

void VolumeAround_SPH::registerKeywords( Keywords& keys ){
  ActionVolume::registerKeywords( keys );
  keys.add("atoms","ATOM","the atom whose vicinity we are interested in examining");
  keys.add("compulsory","NN","6","The n parameter of the switching function ");
  keys.add("compulsory","MM","12","The m parameter of the switching function ");
  keys.add("compulsory","D_0","0.0","The d_0 parameter of the switching function");
  keys.add("compulsory","R_0","The r_0 parameter of the switching function");
  keys.add("optional","SWITCH","This keyword is used if you want to employ an alternative to the continuous swiching function defined above. "
                               "The following provides information on the \\ref switchingfunction that are available. "
                               "When this keyword is present you no longer need the NN, MM, D_0 and R_0 keywords.");
  //keys.remove("SIGMA");
  //keys.remove("KERNELTYPE");
}

VolumeAround_SPH::VolumeAround_SPH(const ActionOptions& ao):
Action(ao),
ActionVolume(ao)
{
  std::vector<AtomNumber> atom; 
  parseAtomList("ATOM",atom);
  if( atom.size()!=1 ) error("should only be one atom specified");
  log.printf("  boundaries for region are calculated based on positions of atom : %d\n",atom[0].serial() );

  // Read in the switching function
  std::string sw, errors; parse("SWITCH",sw);
  if(sw.length()>0){
     switchingFunction.set(sw,errors);
     if( errors.length()!=0 ) error("problem reading SWITCH keyword : " + errors );
  } else {
     double r_0=-1.0, d_0; int nn, mm;
     parse("NN",nn); parse("MM",mm);
     parse("R_0",r_0); parse("D_0",d_0);
     if( r_0<0.0 ) error("you must set a value for R_0");
     switchingFunction.set(nn,mm,r_0,d_0);
  }
  log.printf("Limit the evaluation of a certain CV within a spherical region... %s\n",( switchingFunction.description() ).c_str() );

  checkRead(); requestAtoms(atom); 
}

void VolumeAround_SPH::setupRegions(){ }

double VolumeAround_SPH::calculateNumberInside( const Vector& cpos, Vector& derivatives, Tensor& vir, std::vector<Vector>& refders ) const {

  // Calculate position of atom wrt to origin
  Vector fpos=pbcDistance( getPosition(0), cpos );

  // Get the radial distance
  const double dd=fpos.modulo()*fpos.modulo(); 

  // Get the SW
  double dfunc, vswitch = switchingFunction.calculateSqr( dd, dfunc );

  // Set derivatives to zero
  derivatives.zero();

  // Set the CV
  double value=vswitch;

  // Set the derivatives
  derivatives[0]=dfunc*fpos[0];
  derivatives[1]=dfunc*fpos[1];
  derivatives[2]=dfunc*fpos[2];

  // Add derivatives wrt to position of origin atom
  refders[0] = -derivatives;

  // Add virial contribution
  vir -= Tensor(fpos,derivatives);

  return value;
  
}

}
}
